/***********************************************************************
 * Component:
 *    Week 09, Binary Search Tree (BST)
 * Author:
 *    Heather Brune & Jon Crawford
 * Summary:
 *    Functioning Binary Search Tree and BST iterator which utilizes
 *    Binary Nodes.
 ************************************************************************/
#ifndef BST_H
#define BST_H

#include "bnode.h"    // for BinaryNode
#include "stack.h"    // for Stack

//indicate the iterator
template <class T>
class BSTIterator; 

/*****************************************************************
 * Binary Search Tree (BST)
 *****************************************************************/
template <class T>
class BST
{
public:
   BST(): root(NULL){};   // default constructor
   BST(const BST & rhs);  // copy constructor
   ~BST();                // destructor
   
   //BinaryNode class holds this size function
   int  size() const  { return empty() ? 0 : root->size(); }
   
   // determine if the tree is empty
   bool empty() const
   {
      if (root == NULL)
         return true;
      else
         return false;
   }

   // clear all the contents of the tree
   void clear()
   {
      root = NULL;
      //deleteBinaryTree(root);
   }

   // = assignment operator
   BST & operator = (const BST & rhs) throw (const char *)
   {
      BST<T>* tree = new BST<T>();
      BSTIterator <T> it;
      for (it = rhs.begin(); it != rhs.end(); ++it)
      {
         tree->insert(*it);
      }
      
      this->root = tree->root;
      
      return *this;
   }
      
   // insert an item
   void insert(const T & t) throw (const char * );

   // remove an item
   void remove(BSTIterator <T> & it);

   // find a given item
   BSTIterator <T> find(const T & t);

   // the usual iterator stuff
   BSTIterator <T> begin() const;
   BSTIterator <T> end() const  { return BSTIterator <T> (NULL) ; }
   
   //reverse iterators
   BSTIterator <T> rbegin() const;
   BSTIterator <T> rend() const  { return BSTIterator <T> (NULL); }
   
private:
   BinaryNode <T> * root;   //top of the BST
};

// BST copy constructor
template <class T>
BST<T>::BST(const BST &rhs)
{
   BST<T>* tree = new BST<T>();
   BSTIterator <T> it;
   for (it = rhs.begin(); it != rhs.end(); ++it)
   {
         tree->insert(*it);
   }
   
   root = tree->root;
   
   return;
}

// BST Destructor
template <class T>
BST<T>::~BST()
{
   clear();
}

// Return the first node (left-most node) in the BST
template <class T>
BSTIterator <T> BST <T> :: begin() const
{
   Stack < BinaryNode <T> * > nodes;

   nodes.push(NULL);
   nodes.push(root);
   while (nodes.top() != NULL && nodes.top()->pLeft)
      nodes.push(nodes.top()->pLeft);

   return BSTIterator<T>(nodes);   
}

//Return the last node (right-most node) in the BST
template <class T>
BSTIterator <T> BST <T> :: rbegin() const
{
   Stack < BinaryNode <T> * > nodes;

   nodes.push(NULL);
   nodes.push(root);
   while (nodes.top() != NULL && nodes.top()->pRight)
      nodes.push(nodes.top()->pRight);

   return BSTIterator<T>(nodes);
}  


//Insert a node into the proper location of the currest BST
template <class T>
void BST <T> :: insert(const T & t) throw (const char *)
{
   //is the tree empty
   if (root == NULL)
   {
      root = new BinaryNode<T>(t);
      return;
   }
   
   //create node to attach to the tree
   BinaryNode<T>* local = new BinaryNode<T>();
   local = root;
   
   while (local != NULL)
   {
      if (t <= local->data)
      {
         if (local->pLeft != NULL)
         {
            local = local->pLeft;
         }
         else
         {
            local->addLeft(t);
            break;
         }
      }
      else
      {
         if (local->pRight != NULL)
         {
            local = local->pRight;
         }
         else
         {
            local->addRight(t);
            break;
         }
      }
   }
}

// Remove a given node as specified by the iterator
template <class T>
void BST <T> :: remove(BSTIterator <T> & it)
{
//nothing to remove
if (root == NULL)
   return;

//leaf node
if (it.getNode()->pLeft == NULL && it.getNode()->pRight == NULL)
   {
   BinaryNode<T>* local = new BinaryNode<T>();
   local = it.getNode();
   local->data = ' ';
   }
   
   BinaryNode<T>* local = new BinaryNode<T>();
   local = it.getNode();
   local->data = ' ';

//one child

//two children

}

//Find and return the node corresponding to a given value
template <class T>
BSTIterator <T> BST <T> :: find(const T & t)
{
   BSTIterator <T> it;
   for (it = this->begin(); it != this->end(); ++it)
   {
      if (*it == t)
         return it;
   }
   
   //nothing was found
   return this->end();
}


/**********************************************************
 * BST Iterator
 * Forward and reverse iterator through the BST
 *********************************************************/
template <class T>
class BSTIterator
{
public:
   // constructors
   BSTIterator(BinaryNode <T> * p = NULL)    { nodes.push(p); }        //default constructor
   BSTIterator(Stack <BinaryNode <T> *> & iStack) { nodes = iStack; }  //non-default constructor
   BSTIterator(const BSTIterator <T> & rhs)  { nodes = rhs.nodes; }    //copy constructor

   // assignment operator
   BSTIterator <T> & operator = (const BSTIterator <T> & rhs)
   {
      nodes = rhs.nodes;
      return *this;
   }
   
   // compare between two BST Iterators
   bool operator == (const BSTIterator <T> & rhs) const
   {
      // only need to compare the leaf node 
      return rhs.nodes.const_top() == nodes.const_top();
   }
   bool operator != (const BSTIterator <T> & rhs) const
   {
      // only need to compare the leaf node 
      return rhs.nodes.const_top() != nodes.const_top();
   }
   
   // de-reference to show value
   T & operator * () 
   {
      return nodes.top()->data;
   }

   // iterator increments
   BSTIterator <T> & operator ++ ();
   BSTIterator <T>   operator ++ (int postfix)
   {
      BSTIterator <T> itReturn = *this;
      ++(*this);
      return itReturn;
   }
   
   //iterator decrements
   BSTIterator <T> & operator -- ();
   BSTIterator <T>   operator -- (int postfix)
   {
      BSTIterator <T> itReturn = *this;
      --(*this);
      return itReturn;
   }
   
   // remove seems to need this in order to access or even change the iterator somehow
   friend void BST <T> :: remove(BSTIterator <T> & it);
   
private:
   BinaryNode <T> * getNode() { return nodes.top(); }   // get the node pointer
   Stack < BinaryNode <T> * > nodes;                    // the stack of nodes
};

//travel the iterator forward by one
template <class T>
BSTIterator <T> & BSTIterator <T> :: operator ++ ()
{
   // do nothing if its empty
   if (nodes.top() == NULL)
      return *this;
   
   // if there is a right node, add it in
   if (nodes.top()->pRight != NULL)
   {
      nodes.push(nodes.top()->pRight);
      
      // in case there's more left ones to search through
      while (nodes.top()->pLeft)
         nodes.push(nodes.top()->pLeft);
      return *this;
   }
   
   // there are no right children, the left are done
   BinaryNode <T> * pStore = nodes.top();
   nodes.pop();
   
   // if the parent is the NULL, we really did hit the top of the tree
   if (NULL == nodes.top())
      return *this;
   
   // if we are the left-child, got to the parent.
   if (pStore == nodes.top()->pLeft)
      return *this;
   
   // we are the right-child, go up as long as we are the right child!
   while (nodes.top() != NULL && pStore == nodes.top()->pRight)
   {
      pStore = nodes.top();
      nodes.pop();
   }
   
   return *this;
}

//travel the iterator backward by one
template <class T>
BSTIterator <T> & BSTIterator <T> :: operator -- ()
{
   // do nothing if its empty
   if (nodes.top() == NULL)
      return *this;
   
   // if there is a left node add it in
   if (nodes.top()->pLeft != NULL)
   {
      nodes.push(nodes.top()->pLeft);
      
      // there might be more right-most children
      while (nodes.top()->pRight)
         nodes.push(nodes.top()->pRight);
      return *this;
   }
   
   // there are no left children, the right are done
   BinaryNode <T> * pStore = nodes.top();
   nodes.pop();
   
   // if the parent is the NULL, we are done!
   if (NULL == nodes.top())
      return *this;
   
   // if we are the right-child, got to the parent.
   if (pStore == nodes.top()->pRight)
      return *this;
   
   // we are the left-child, go up as long as we are the left child!
   while (nodes.top() != NULL && pStore == nodes.top()->pLeft)
   {
      pStore = nodes.top();
      nodes.pop();
   }

   return *this;
}

#endif // BST_H